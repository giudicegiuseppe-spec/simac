// netlify/functions/reminders.js
var getStore = null;
try {
  ({ getStore } = require("@netlify/blobs"));
} catch (e) {
  getStore = null;
}
var STORE_NAME = "agenda";
var KEY_APPTS = "appointments.json";
var KEY_REMIND = "reminders.json";
var SITE_LABEL = "retesimac";
function newStore() {
  if (!getStore) return null;
  try {
    return getStore(STORE_NAME);
  } catch (_) {
    return null;
  }
}
async function readAppointments() {
  const store = newStore();
  if (!store || typeof store.get !== "function") return [];
  try {
    const data = await store.get(KEY_APPTS, { type: "json" });
    return Array.isArray(data) ? data : [];
  } catch (_) {
    return [];
  }
}
async function readReminderState() {
  const store = newStore();
  if (!store || typeof store.get !== "function") return {};
  try {
    const data = await store.get(KEY_REMIND, { type: "json" });
    return data && typeof data === "object" ? data : {};
  } catch (_) {
    return {};
  }
}
async function writeReminderState(obj) {
  const store = newStore();
  if (!store || typeof store.set !== "function") return;
  try {
    await store.set(KEY_REMIND, JSON.stringify(obj || {}), { contentType: "application/json" });
  } catch (_) {
  }
}
function tgEnabled() {
  try {
    return String(process.env.TELEGRAM_ENABLED || "1") === "1" && !!process.env.TELEGRAM_BOT_TOKEN;
  } catch (_) {
    return false;
  }
}
function csvParse(text) {
  const lines = String(text || "").split(/\r?\n/).filter(Boolean);
  if (!lines.length) return [];
  const sep = lines[0].includes(";") && !lines[0].includes(",") ? ";" : ",";
  const cells = (s) => s.split(sep).map((x) => x.replace(/^"|"$/g, "").trim());
  const header = cells(lines[0]).map((h) => h.toLowerCase());
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const vals = cells(lines[i]);
    const o = {};
    for (let j = 0; j < header.length; j++) {
      o[header[j]] = vals[j] || "";
    }
    rows.push(o);
  }
  return rows;
}
var TELE_USERS_CACHE = { ts: 0, map: {} };
async function loadTelegramMap() {
  const now = Date.now();
  if (TELE_USERS_CACHE.ts && now - TELE_USERS_CACHE.ts < 5 * 60 * 1e3) {
    return TELE_USERS_CACHE.map;
  }
  const url = process.env.TELEGRAM_USERS_CSV_URL || "";
  const map = {};
  try {
    if (url) {
      const r = await fetch(url);
      if (r.ok) {
        const txt = await r.text();
        const rows = csvParse(txt);
        for (const r0 of rows) {
          const em = (r0.email || "").trim().toLowerCase();
          const id = (r0.chat_id || "").trim();
          if (em && id) map[em] = id;
        }
      }
    }
  } catch (_) {
  }
  TELE_USERS_CACHE = { ts: now, map };
  return map;
}
async function resolveChatId(email) {
  try {
    const map = await loadTelegramMap();
    return map[String(email || "").toLowerCase()] || "";
  } catch (_) {
    return "";
  }
}
async function sendTelegram(chatId, text) {
  try {
    const tok = process.env.TELEGRAM_BOT_TOKEN;
    if (!(tok && chatId && text)) return false;
    const rc = await fetch(`https://api.telegram.org/bot${tok}/sendMessage`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML", disable_web_page_preview: true }) });
    return rc.ok;
  } catch (_) {
    return false;
  }
}
function fmtRec(rec) {
  const lines = [];
  lines.push(`<b>Cliente:</b> ${rec.cliente || ""}`);
  lines.push(`<b>Data/Ora:</b> ${rec.start_at || ""}`);
  if (rec.luogo) lines.push(`<b>Luogo:</b> ${rec.luogo}`);
  if (rec.note) lines.push(`<b>Note:</b> ${rec.note}`);
  return lines.join("\n");
}
function romeNowHour() {
  try {
    const fmt = new Intl.DateTimeFormat("it-IT", { hour: "numeric", hour12: false, timeZone: "Europe/Rome" });
    const parts = fmt.formatToParts(/* @__PURE__ */ new Date());
    const h = Number((parts.find((p) => p.type === "hour") || {}).value || "0");
    return isNaN(h) ? 0 : h;
  } catch (_) {
    return (/* @__PURE__ */ new Date()).getUTCHours();
  }
}
function isQuietHours() {
  const h = romeNowHour();
  return h >= 23 || h < 8;
}
function hoursSince(iso) {
  try {
    const t = Date.parse(iso);
    if (!t) return Infinity;
    return (Date.now() - t) / 36e5;
  } catch (_) {
    return Infinity;
  }
}
exports.handler = async function() {
  const res = { ok: true, sent: 0, checked: 0, skippedQuiet: 0 };
  try {
    if (!tgEnabled()) return { statusCode: 200, body: JSON.stringify({ ok: true, reason: "telegram disabled" }) };
    const all = await readAppointments();
    const state = await readReminderState();
    const due = (all || []).filter((r) => String(r.stato || "") === "Nuovo");
    for (const rec of due) {
      res.checked++;
      const hSinceCreate = hoursSince(rec.created_at || rec.updated_at);
      if (hSinceCreate < 12) continue;
      const key = rec.id;
      const last = state[key] && state[key].lastReminderAt ? Date.parse(state[key].lastReminderAt) : 0;
      if (last && Date.now() - last < 2 * 36e5) continue;
      if (isQuietHours()) {
        res.skippedQuiet++;
        continue;
      }
      const chatId = await resolveChatId(rec.agente_id || rec.agente_email || "");
      const adminId = process.env.TELEGRAM_ADMIN_CHAT_ID || "";
      const msg = `\u23F0 <b>Promemoria appuntamento</b>
<b>CRM:</b> ${SITE_LABEL}
${fmtRec(rec)}

Stato attuale: ${rec.stato || ""}`;
      let ok = false;
      if (chatId) {
        ok = await sendTelegram(chatId, msg);
      } else if (adminId) {
        ok = await sendTelegram(adminId, `\u26A0\uFE0F Nessun chat_id per ${rec.agente_id || ""}
` + msg);
      }
      if (ok) {
        state[key] = { lastReminderAt: (/* @__PURE__ */ new Date()).toISOString(), count: (state[key] && state[key].count || 0) + 1 };
        res.sent++;
      }
    }
    await writeReminderState(state);
    return { statusCode: 200, body: JSON.stringify(res) };
  } catch (e) {
    return { statusCode: 200, body: JSON.stringify({ ok: false, error: String(e && e.message || e) }) };
  }
};
exports.config = { schedule: "*/30 * * * *" };
